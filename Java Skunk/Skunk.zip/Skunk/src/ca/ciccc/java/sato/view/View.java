package ca.ciccc.java.sato.view;

import java.util.Scanner;

import ca.ciccc.java.sato.model.Player;

/**
 * 
 * @author Wataru Sato
 *
 */
public class View {
	private Scanner scan;

	/**
	 * To display massage for getting player's decision
	 * 
	 * @return input which represents whether player continue game or not
	 */
	public String getUserDecision() {
		scan = new Scanner(System.in);
		String input;

		System.out.println("");
		System.out.print("Do you want to continue the game? (Type \"y\" or \"n\") : ");
		input = scan.next();

		while (!(input.equals("y")) && !(input.equals("n"))) {
			System.out.println("\"" + input + "\" is unacceptable. Type again!");
			System.out.print("Do you want to continue the game? (Type \"y\" or \"n\") : ");
			input = scan.next();
		}
		return input;
	}

	/**
	 * To display title of game
	 */
	public void dispTitle() {
		System.out.println("----------SKUNK----------");
	}

	/**
	 * To display name of round
	 * 
	 * @param round
	 *            which is a letter part of "SKUNK"
	 */
	public void dispRound(String round) {
		System.out.println("");
		System.out.println("********** " + round + " **********");
	}

	/**
	 * To display number of dices
	 * 
	 * @param dice1 to roll
	 * @param dice2 to roll
	 */
	public void dispNumberOfDice(int dice1, int dice2) {
		System.out.println("");
		System.out.println("Dice1 : " + dice1 + " Dice2 : " + dice2);
	}

	/**
	 * To display player's score
	 * 
	 * @param player
	 *            who participate the game
	 */
	public void dispScore(Player player) {
		String status;
		if (player.isStatus()) {
			status = "Stand";
		} else {
			status = "Sit";
		}

		System.out.println("[ " + player.getName() + " ] Score : " + player.getCurrentScore() + "  Total Score : "
				+ player.getTotalScore() + "  ( Status : " + status + " )");
	}

	/**
	 * To display "RESULT" which would be above final score
	 */
	public void dispResult() {
		System.out.println("");
		System.out.println("=============== RESULT ===============");
	}

	/**
	 * To display final score
	 * 
	 * @param num
	 *            which represents rank
	 * @param player
	 *            who participate the game
	 */
	public void dispFinalScore(int num, Player player) {
		System.out.println("#" + num + "  [ " + player.getName() + " ]  " + player.getTotalScore() + " points");
	}

}
