package ca.ciccc.java.sato.model;

/**
 * 
 * @author Wataru Sato
 *
 */

public abstract class Player {
	private String name;
	private int currentScore;
	private int totalScore;
	private boolean status;

	/**
	 * Constructor
	 * 
	 * @param name
	 *            of player
	 */
	public Player(String name) {
		setName(name);
		setStatus(true);
	}

	/**
	 * To judge whether player continue game or not
	 */
	public abstract void continueGame();

	/**
	 * To calculate round score
	 * 
	 * @param score
	 *            that player gain
	 */
	public void addCurrentScore(int score) {
		this.currentScore += score;
	}

	/**
	 * To erase round score
	 */
	public void eraseCurrentScore() {
		this.currentScore = 0;
	}

	/**
	 * To calculate total score
	 */
	public void addTotalScore() {
		this.totalScore += this.currentScore;
	}

	/**
	 * To erase total score
	 */
	public void eraseTotalScore() {
		this.totalScore = 0;
	}

	/**
	 * Getter for name
	 * 
	 * @return player's name
	 */
	public final String getName() {
		return name;
	}

	/**
	 * Setter for name
	 * 
	 * @param name
	 *            of player
	 */
	public final void setName(String name) {
		this.name = name;
	}

	/**
	 * Getter for round score
	 * 
	 * @return score that player gain in each round
	 */
	public final int getCurrentScore() {
		return currentScore;
	}

	/**
	 * Getter for total score
	 * 
	 * @return total score
	 */
	public final int getTotalScore() {
		return totalScore;
	}

	/**
	 * Setter for total score
	 * 
	 * @param totalScore that player gain in total
	 */
	public final void setTotalScore(int totalScore) {
		this.totalScore = totalScore;
	}

	/**
	 * Getter for status
	 * 
	 * @return status which represents whether player continue game or not
	 */
	public final boolean isStatus() {
		return status;
	}

	/**
	 * Setter for status
	 * 
	 * @param status
	 *            which represents whether player continue game or not
	 */
	public final void setStatus(boolean status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Player [name=" + name + ", currentScore=" + currentScore + ", totalScore=" + totalScore + ", status="
				+ status + "]";
	}

}
