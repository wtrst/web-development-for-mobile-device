package ca.ciccc.java.sato.model;

import java.util.Random;

/**
 * 
 * @author Wataru Sato
 *
 */
public class Dice {
	private int numberOfDice;

	/**
	 * Constructor
	 */
	public Dice() {
		rollDice();
	}

	/**
	 * To roll dice with random number
	 */
	public void rollDice() {
		Random random = new Random();
		this.numberOfDice = random.nextInt(6) + 1;
	}

	/**
	 * Getter for number of dice
	 * 
	 * @return number of dice
	 */
	public final int getNumberOfDice() {
		return numberOfDice;
	}

}
