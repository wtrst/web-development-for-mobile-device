package ca.ciccc.java.sato.model;

import java.util.Comparator;

/**
 * 
 * @author Wataru Sato
 *
 */
public class ScoreComparator implements Comparator<Player> {

	@Override
	public int compare(Player o1, Player o2) {
		return o2.getTotalScore() - o1.getTotalScore();
	}

}
