package ca.ciccc.java.sato.model;

import java.util.Random;

/**
 * 
 * @author Wataru Sato
 *
 */
public class Computer extends Player {
	private Random rdm;

	/**
	 * Constructor
	 * @param name of player
	 */
	public Computer(String name) {
		super(name);
		rdm = new Random();
	}
	
	@Override
	public void continueGame() {
		int rdmNumber;
		rdmNumber = rdm.nextInt(10) + 1;

		if (rdmNumber > 3) {
			setStatus(true);
		} else {
			setStatus(false);
		}
	}

}
