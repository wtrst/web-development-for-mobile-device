package ca.ciccc.java.sato.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

import ca.ciccc.java.sato.model.*;
import ca.ciccc.java.sato.view.*;

/**
 * 
 * @author Wataru Sato
 *
 */
public class Controller {
	private ArrayList<Player> players;
	private View view;
	private Dice dice1;
	private Dice dice2;
	private Human human;
	private Computer com1;
	private Computer com2;
	private Computer com3;

	/**
	 * Constructor
	 */
	public Controller() {
		players = new ArrayList<Player>();
		view = new View();
		dice1 = new Dice();
		dice2 = new Dice();
		human = new Human("YOU");
		com1 = new Computer("COM1");
		com2 = new Computer("COM2");
		com3 = new Computer("COM3");
	}

	/**
	 * To call dispTitle method in View
	 */
	public void dispDetailOfTitle() {
		view.dispTitle();
	}

	/**
	 * To call dispRound method in View
	 * 
	 * @param round
	 *            which is a letter part of "SKUNK"
	 */
	public void dispDetailOfRound(String round) {
		view.dispRound(round);
	}

	/**
	 * To call dispNumberOfDice method in View
	 */
	public void dispDetailOfDices() {
		view.dispNumberOfDice(dice1.getNumberOfDice(), dice2.getNumberOfDice());
	}

	/**
	 * To check number of dices
	 * 
	 * @return number to judge behavior after rolling the dices
	 */
	public int checkNumberOfDices() {
		if (dice1.getNumberOfDice() == 1 && dice2.getNumberOfDice() == 1) {
			return 1;
		} else if (dice1.getNumberOfDice() == 1 || dice2.getNumberOfDice() == 1) {
			return 2;
		} else {
			return 3;
		}
	}

	/**
	 * To get score
	 * 
	 * @return sum of 2 dices
	 */
	public int getSumScore() {
		return dice1.getNumberOfDice() + dice2.getNumberOfDice();
	}

	/**
	 * To add player into array list
	 */
	public void addPlayers() {
		players.add(human);
		players.add(com1);
		players.add(com2);
		players.add(com3);
	}

	/**
	 * To call dispScore method in View
	 * 
	 * @param player
	 *            who participate the game
	 */
	public void dispDetailOfPlayers(Player player) {
		view.dispScore(player);
	}

	/**
	 * To get every player's status
	 * 
	 * @return true or false to change round
	 */
	public boolean getAllPlayersStatus() {
		Iterator<Player> plyr1 = players.iterator();
		while (plyr1.hasNext()) {
			Player p1 = plyr1.next();
			if (p1.isStatus()) {
				return true;
			}
		}
		return false;
	}

	/**
	 * To call rollDice method in Dice
	 */
	public void getNumberOfDices() {
		dice1.rollDice();
		dice2.rollDice();
	}

	/**
	 * To check and set user's decision
	 */
	public void checkUserDecision() {
		if (human.isStatus()) {
			human.setInput(view.getUserDecision());
		}
	}

	/**
	 * To call dispResult method and dispFinalScore method in View
	 * 
	 * @param players
	 *            who participate the game
	 */
	public void getFinalResult(ArrayList<Player> players) {
		view.dispResult();

		int num = 1;
		Iterator<Player> plyr4 = players.iterator();
		while (plyr4.hasNext()) {
			Player p4 = plyr4.next();
			view.dispFinalScore(num, p4);
			num++;
		}
	}

	public static void main(String[] args) {
		Controller controller = new Controller();
		controller.dispDetailOfTitle();
		controller.addPlayers();

		int numberOfRound = 0;
		String[] round = { "S", "K", "U", "N", "K" };
		while (numberOfRound < 5) {
			int cnt = 1;
			int checkNum = 3;
			controller.dispDetailOfRound(round[numberOfRound]);
			while (controller.getAllPlayersStatus() && checkNum == 3) {
				if (cnt != 1) {
					controller.checkUserDecision();
				}
				checkNum = controller.checkNumberOfDices();
				if (cnt == 1 && checkNum != 3) {
					while (checkNum != 3) {
						controller.getNumberOfDices();
						checkNum = controller.checkNumberOfDices();
					}
				}
				controller.dispDetailOfDices();
				Iterator<Player> plyr2 = controller.players.iterator();
				while (plyr2.hasNext()) {
					Player p2 = plyr2.next();

					if (cnt != 1 && p2.isStatus()) {
						p2.continueGame();
					}

					if (p2.isStatus()) {
						if (checkNum == 3) {
							p2.addCurrentScore(controller.getSumScore());
						} else if (checkNum == 2) {
							p2.eraseCurrentScore();
						} else {
							p2.eraseCurrentScore();
							p2.eraseTotalScore();
						}
					} else {
						p2.addTotalScore();
						p2.eraseCurrentScore();
					}
					controller.dispDetailOfPlayers(p2);
				}
				controller.getNumberOfDices();
				cnt++;
			}
			Iterator<Player> plyr3 = controller.players.iterator();
			while (plyr3.hasNext()) {
				Player p3 = plyr3.next();
				p3.setStatus(true);
			}
			numberOfRound++;
		}
		Collections.sort(controller.players, new ScoreComparator());
		controller.getFinalResult(controller.players);

	}
}
