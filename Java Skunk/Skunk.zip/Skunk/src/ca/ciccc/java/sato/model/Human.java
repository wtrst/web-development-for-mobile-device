package ca.ciccc.java.sato.model;

/**
 * 
 * @author Wataru Sato
 *
 */
public class Human extends Player {
	private String input;

	/**
	 * Constructor
	 * 
	 * @param name
	 *            of player
	 */
	public Human(String name) {
		super(name);
	}

	@Override
	public void continueGame() {
		if (getInput().equals("y")) {
			setStatus(true);
			;
		} else {
			setStatus(false);
		}

	}

	/**
	 * Getter for input
	 * 
	 * @return input which represents whether player continue game or not
	 */
	public final String getInput() {
		return input;
	}

	/**
	 * Setter for input
	 * 
	 * @param input
	 *            which represents whether player continue game or not
	 */
	public final void setInput(String input) {
		this.input = input;
	}

}
