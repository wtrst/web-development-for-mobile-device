
public class Player {
	private int dice1;
	private int dice2;
	
}
