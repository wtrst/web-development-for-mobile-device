package ca.ciccc.java.sato.model;

public class Parent extends Employee implements Comparable<Parent> {

	private int numberOfHoursSpentPerWeekWithKids;

	public Parent(String name, int numberOfHoursSpentPerWeekWithKids) {
		super(name);
		this.numberOfHoursSpentPerWeekWithKids = numberOfHoursSpentPerWeekWithKids;
	}

	@Override
	public String toString() {
		return "Parent [numberOfHoursSpentPerWeekWithKids=" + numberOfHoursSpentPerWeekWithKids + "]";
	}

	@Override
	public DressCode getDressCode() {
		// TODO Auto-generated method stub
		return DressCode.ANYTHING;
	}

	@Override
	public boolean isPaidSalary() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean postSecondaryEducationRequired() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getWorkVerb() {
		// TODO Auto-generated method stub
		return "care";
	}

	@Override
	public double getOverTimePayRate() {
		// TODO Auto-generated method stub
		return -2.0;
	}

	@Override
	public String getDetail() {
		return getName() + " spends " + this.numberOfHoursSpentPerWeekWithKids + " hour/week with kids";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + numberOfHoursSpentPerWeekWithKids;
		return result;
	}

	@Override
	public boolean equals(Object that) {
		if (this == that) {
			return true;
		}
		if (that == null) {
			return false;
		}
		if (this.getClass() != that.getClass()) {
			return false;
		}
		Parent other = (Parent) that;

		if (this.numberOfHoursSpentPerWeekWithKids != other.numberOfHoursSpentPerWeekWithKids) {
			return false;
		}
		return true;
	}

	@Override
	public int compareTo(Parent obj) {
		if (this.numberOfHoursSpentPerWeekWithKids < obj.numberOfHoursSpentPerWeekWithKids) {
			return 1;
		} else if (this.numberOfHoursSpentPerWeekWithKids > obj.numberOfHoursSpentPerWeekWithKids) {
			return -1;
		}
		return 0;
	}

}
