package ca.ciccc.java.sato.model;

public class Parent extends Employee{

	private int numberOfHoursSpentPerWeekWithKids;
	
	public Parent(String name, int numberOfHoursSpentPerWeekWithKids) {
		super(name);
		this.numberOfHoursSpentPerWeekWithKids = numberOfHoursSpentPerWeekWithKids;
	}
	
	@Override
	public String toString() {
		return "Parent [numberOfHoursSpentPerWeekWithKids=" + numberOfHoursSpentPerWeekWithKids + "]";
	}

	@Override
	public DressCode getDressCode() {
		// TODO Auto-generated method stub
		return DressCode.ANYTHING;
	}

	@Override
	public boolean isPaidSalary() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean postSecondaryEducationRequired() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getWorkVerb() {
		// TODO Auto-generated method stub
		return "care";
	}

	@Override
	public double getOverTimePayRate() {
		// TODO Auto-generated method stub
		return -2.0;
	}

}
