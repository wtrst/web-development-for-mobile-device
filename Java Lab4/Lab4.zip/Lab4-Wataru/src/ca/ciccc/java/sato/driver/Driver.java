package ca.ciccc.java.sato.driver;

import ca.ciccc.java.sato.model.Employees;

public class Driver {
	public static void main(String[] args) {
		Employees emps = new Employees();
		
	}
}
