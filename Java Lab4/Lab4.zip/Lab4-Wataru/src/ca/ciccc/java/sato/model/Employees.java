package ca.ciccc.java.sato.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

/**
 * 
 * @author Wataru Sato
 *
 */
public class Employees {

	private ArrayList<Employee> employees;
	private ArrayList<HockeyPlayer> hockeyPlayers;
	private ArrayList<Professor> professors;
	private ArrayList<Parent> parents;
	private ArrayList<GasStationAttendant> gasStationAttendants;

	public Employees() {
		employees = new ArrayList<Employee>();

		employees.add(new HockeyPlayer("Wayne Gretzky", 894));
		employees.add(new HockeyPlayer("Who Ever", 0));
		employees.add(new HockeyPlayer("Brent Gretzky", 1));
		employees.add(new HockeyPlayer("Pavel Bure", 437));
		employees.add(new HockeyPlayer("Jason Bourne", 0));

		employees.add(new Professor("Albert Einstein", "Physics"));
		employees.add(new Professor("Alan Turing", "Computer Systems"));
		employees.add(new Professor("Richard Feynman", "Physics"));
		employees.add(new Professor("Tim Berners-Lee", "Computer Systems"));
		employees.add(new Professor("Kurt Godel", "Logic"));

		employees.add(new Parent("Tiger Woods", 1));
		employees.add(new Parent("Super Mom", 168));
		employees.add(new Parent("Lazy Larry", 20));
		employees.add(new Parent("Ex Hausted", 168));
		employees.add(new Parent("Super Dad", 167));

		employees.add(new GasStationAttendant("Joe Smith", 10));
		employees.add(new GasStationAttendant("Tony Baloney", 100));
		employees.add(new GasStationAttendant("Benjamin Franklin", 100));
		employees.add(new GasStationAttendant("Mary Fairy", 101));
		employees.add(new GasStationAttendant("Bee See", 1));

		hockeyPlayers = new ArrayList<HockeyPlayer>();

		hockeyPlayers.add(new HockeyPlayer("Wayne Gretzky", 894));
		hockeyPlayers.add(new HockeyPlayer("Who Ever", 0));
		hockeyPlayers.add(new HockeyPlayer("Brent Gretzky", 1));
		hockeyPlayers.add(new HockeyPlayer("Pavel Bure", 437));
		hockeyPlayers.add(new HockeyPlayer("Jason Bourne", 0));

		professors = new ArrayList<Professor>();

		professors.add(new Professor("Albert Einstein", "Physics"));
		professors.add(new Professor("Alan Turing", "Computer Systems"));
		professors.add(new Professor("Richard Feynman", "Physics"));
		professors.add(new Professor("Tim Berners-Lee", "Computer Systems"));
		professors.add(new Professor("Kurt Godel", "Logic"));

		parents = new ArrayList<Parent>();

		parents.add(new Parent("Tiger Woods", 1));
		parents.add(new Parent("Super Mom", 168));
		parents.add(new Parent("Lazy Larry", 20));
		parents.add(new Parent("Ex Hausted", 168));
		parents.add(new Parent("Super Dad", 167));

		gasStationAttendants = new ArrayList<GasStationAttendant>();

		gasStationAttendants.add(new GasStationAttendant("Joe Smith", 10));
		gasStationAttendants.add(new GasStationAttendant("Tony Baloney", 100));
		gasStationAttendants.add(new GasStationAttendant("Benjamin Franklin", 100));
		gasStationAttendants.add(new GasStationAttendant("Mary Fairy", 101));
		gasStationAttendants.add(new GasStationAttendant("Bee See", 1));

	}

	public static void main(String[] args) {
		Employees e = new Employees();

		Iterator<Employee> emp = e.employees.iterator();
		while (emp.hasNext()) {
			System.out.println(emp.next().getDetail());
		}

		System.out.println("");
		System.out.println("-- Array list of Hockey player (before sort)--------");
		Iterator<HockeyPlayer> hockey1 = e.hockeyPlayers.iterator();
		while (hockey1.hasNext()) {
			System.out.println(hockey1.next().getDetail());
		}

		Collections.sort(e.hockeyPlayers);

		System.out.println("");
		System.out.println("-- Array list of Hockey player (after sort)--------");
		Iterator<HockeyPlayer> hockey2 = e.hockeyPlayers.iterator();
		while (hockey2.hasNext()) {
			System.out.println(hockey2.next().getDetail());
		}

		System.out.println("");
		System.out.println("-- Array list of Professor (before sort)--------");
		Iterator<Professor> professor1 = e.professors.iterator();
		while (professor1.hasNext()) {
			System.out.println(professor1.next().getDetail());
		}

		Collections.sort(e.professors);

		System.out.println("");
		System.out.println("-- Array list of Professor (after sort)--------");
		Iterator<Professor> professor2 = e.professors.iterator();
		while (professor2.hasNext()) {
			System.out.println(professor2.next().getDetail());
		}

		System.out.println("");
		System.out.println("-- Array list of Parent (before sort)--------");
		Iterator<Parent> parent1 = e.parents.iterator();
		while (parent1.hasNext()) {
			System.out.println(parent1.next().getDetail());
		}

		Collections.sort(e.parents);

		System.out.println("");
		System.out.println("-- Array list of Parent (after sort)--------");
		Iterator<Parent> parent2 = e.parents.iterator();
		while (parent2.hasNext()) {
			System.out.println(parent2.next().getDetail());
		}

		System.out.println("");
		System.out.println("-- Array list of Gas station attendant (before sort)--------");
		Iterator<GasStationAttendant> gasStation1 = e.gasStationAttendants.iterator();
		while (gasStation1.hasNext()) {
			System.out.println(gasStation1.next().getDetail());
		}

		Collections.sort(e.gasStationAttendants);

		System.out.println("");
		System.out.println("-- Array list of Gas station attendant (after sort)--------");
		Iterator<GasStationAttendant> gasStation2 = e.gasStationAttendants.iterator();
		while (gasStation2.hasNext()) {
			System.out.println(gasStation2.next().getDetail());
		}
	}

}
