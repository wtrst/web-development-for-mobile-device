package ca.ciccc.java.sato.model;

/**
 * 
 * @author Wataru Sato
 *
 */
public class HockeyPlayer extends Employee implements Comparable<HockeyPlayer> {

	private int numberOfGoals;

	public HockeyPlayer(String name, int numberOfGoals) {
		super(name);
		this.numberOfGoals = numberOfGoals;
	}

	@Override
	public String toString() {
		return "HockeyPlayer [numberOfGoals=" + numberOfGoals + "]";
	}

	@Override
	public DressCode getDressCode() {
		return DressCode.JERSEY;
	}

	@Override
	public boolean isPaidSalary() {
		return true;
	}

	@Override
	public boolean postSecondaryEducationRequired() {
		return false;
	}

	@Override
	public String getWorkVerb() {
		return "play";
	}

	@Override
	public double getOverTimePayRate() {
		return 0.0;
	}

	@Override
	public String getDetail() {
		return getName() + " scored " + this.numberOfGoals + " goals";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + numberOfGoals;
		return result;
	}

	@Override
	public boolean equals(Object that) {
		if (this == that) {
			return true;
		}
		if (that == null) {
			return false;
		}
		if (this.getClass() != that.getClass()) {
			return false;
		}
		HockeyPlayer other = (HockeyPlayer) that;

		if (this.numberOfGoals != other.numberOfGoals) {
			return false;
		}
		return true;
	}

	@Override
	public int compareTo(HockeyPlayer obj) {
		if (this.numberOfGoals < obj.numberOfGoals) {
			return 1;
		} else if (this.numberOfGoals > obj.numberOfGoals) {
			return -1;
		}
		return 0;
	}

}
