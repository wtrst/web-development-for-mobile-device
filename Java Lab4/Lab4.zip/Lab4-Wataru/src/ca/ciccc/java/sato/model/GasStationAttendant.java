package ca.ciccc.java.sato.model;

public class GasStationAttendant extends Employee{

	private double numberOfDollarsStolenPerDay;
	
	public GasStationAttendant(String name, double numberOfDollarsStolenPerDay) {
		super(name);
		this.numberOfDollarsStolenPerDay = numberOfDollarsStolenPerDay;
	}
	
	@Override
	public String toString() {
		return "GasStationAttendant [numberOfDollarsStolenPerDay=" + numberOfDollarsStolenPerDay + "]";
	}

	@Override
	public DressCode getDressCode() {
		// TODO Auto-generated method stub
		return DressCode.UNIFORM;
	}

	@Override
	public boolean isPaidSalary() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean postSecondaryEducationRequired() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getWorkVerb() {
		// TODO Auto-generated method stub
		return "pump";
	}

	@Override
	public double getOverTimePayRate() {
		// TODO Auto-generated method stub
		return 1.5;
	}

}
