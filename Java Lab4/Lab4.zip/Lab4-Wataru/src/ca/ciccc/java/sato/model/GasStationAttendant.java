package ca.ciccc.java.sato.model;

public class GasStationAttendant extends Employee implements Comparable<GasStationAttendant> {

	private double numberOfDollarsStolenPerDay;

	public GasStationAttendant(String name, double numberOfDollarsStolenPerDay) {
		super(name);
		this.numberOfDollarsStolenPerDay = numberOfDollarsStolenPerDay;
	}

	@Override
	public String toString() {
		return "GasStationAttendant [numberOfDollarsStolenPerDay=" + numberOfDollarsStolenPerDay + "]";
	}

	@Override
	public DressCode getDressCode() {
		// TODO Auto-generated method stub
		return DressCode.UNIFORM;
	}

	@Override
	public boolean isPaidSalary() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean postSecondaryEducationRequired() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getWorkVerb() {
		// TODO Auto-generated method stub
		return "pump";
	}

	@Override
	public double getOverTimePayRate() {
		// TODO Auto-generated method stub
		return 1.5;
	}

	@Override
	public String getDetail() {
		return getName() + " steals " + this.numberOfDollarsStolenPerDay + " dollars a day";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(numberOfDollarsStolenPerDay);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object that) {
		if (this == that) {
			return true;
		}
		if (that == null) {
			return false;
		}
		if (this.getClass() != that.getClass()) {
			return false;
		}
		GasStationAttendant other = (GasStationAttendant) that;

		if (this.numberOfDollarsStolenPerDay != other.numberOfDollarsStolenPerDay) {
			return false;
		}
		return true;
	}

	@Override
	public int compareTo(GasStationAttendant obj) {
		if (this.numberOfDollarsStolenPerDay < obj.numberOfDollarsStolenPerDay) {
			return 1;
		} else if (this.numberOfDollarsStolenPerDay > obj.numberOfDollarsStolenPerDay) {
			return -1;
		}
		return 0;
	}

}
