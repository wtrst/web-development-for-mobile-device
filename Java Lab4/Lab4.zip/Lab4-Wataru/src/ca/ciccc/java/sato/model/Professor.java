package ca.ciccc.java.sato.model;

public class Professor extends Employee implements Comparable<Professor> {

	private String teachingMajor;

	public Professor(String name, String teachingMajor) {
		super(name);
		this.teachingMajor = teachingMajor;
	}

	@Override
	public String toString() {
		return "Professor [teachingMajor=" + teachingMajor + "]";
	}

	@Override
	public DressCode getDressCode() {
		// TODO Auto-generated method stub
		return DressCode.FANCY;
	}

	@Override
	public boolean isPaidSalary() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean postSecondaryEducationRequired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public String getWorkVerb() {
		// TODO Auto-generated method stub
		return "teach";
	}

	@Override
	public double getOverTimePayRate() {
		// TODO Auto-generated method stub
		return 2.0;
	}

	@Override
	public String getDetail() {
		return getName() + " teaches " + this.teachingMajor;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((teachingMajor == null) ? 0 : teachingMajor.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object that) {
		if (this == that) {
			return true;
		}
		if (that == null) {
			return false;
		}
		if (this.getClass() != that.getClass()) {
			return false;
		}
		Professor other = (Professor) that;

		if (this.teachingMajor != other.teachingMajor) {
			return false;
		}
		return true;
	}

	@Override
	public int compareTo(Professor obj) {
		return this.teachingMajor.compareTo(obj.teachingMajor);
	}

}
