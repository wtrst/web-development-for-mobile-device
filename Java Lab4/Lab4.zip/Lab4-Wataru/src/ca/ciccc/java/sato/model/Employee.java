package ca.ciccc.java.sato.model;

/**
 * 
 * @author Wataru Sato
 *
 */
public abstract class Employee implements Employable {
	private String name;

	public Employee(String name) {
		this.name = name;
	}
	
	/**
	 * Getter for over time pay rate
	 * 
	 * @return over time pay rate
	 */
	abstract public double getOverTimePayRate();

	/**
	 * Getter for name
	 * 
	 * @return name
	 */
	public final String getName() {
		return name;
	}

	/**
	 * Setter for name
	 * 
	 * @param name
	 */
	public final void setName(String name) {
		this.name = name;
	}

	/**
	 * To print a result as a sentence
	 * 
	 * @return result 
	 */
	abstract public String getDetail();
}
