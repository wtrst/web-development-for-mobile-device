package ca.ciccc.java.sato.model;

/**
 * 
 * @author Wataru Sato
 *
 */
public enum DressCode {

	JERSEY("jersey"), FANCY("fancy"), ANYTHING("anything"), UNIFORM("uniform");

	private String description;

	DressCode(String description) {
		this.description = description;
	}

	/**
	 * Getter for description
	 * 
	 * @return description
	 */
	public String getDescription() {
		return description;
	}
}
