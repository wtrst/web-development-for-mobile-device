package ca.ciccc.java.sato.model;
public enum DressCode {

	JERSEY("jersey"), FANCY("fancy"), ANYTHING("anything"), UNIFORM("uniform");

	private String description;

	DressCode (String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}
}
