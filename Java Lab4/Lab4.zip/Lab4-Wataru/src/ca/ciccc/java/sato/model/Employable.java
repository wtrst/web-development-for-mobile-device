package ca.ciccc.java.sato.model;

public interface Employable {
	public DressCode getDressCode();
	public boolean isPaidSalary();
	public boolean postSecondaryEducationRequired();
	public String getWorkVerb();
}
