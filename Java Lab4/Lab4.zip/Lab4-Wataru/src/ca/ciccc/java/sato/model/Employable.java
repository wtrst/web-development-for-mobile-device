package ca.ciccc.java.sato.model;

/**
 * 
 * @author Wataru Sato
 *
 */
public interface Employable {
	/**
	 * Getter for dress code from enumeration class
	 * 
	 * @return dress code
	 */
	public DressCode getDressCode();

	/**
	 * Getter for paid salary
	 * 
	 * @return a state whether salary has been paid or not 
	 */
	public boolean isPaidSalary();

	/**
	 * Getter for secondary education required
	 * 
	 * @return a state whether secondary education is required or not
	 */
	public boolean postSecondaryEducationRequired();

	/**
	 * Getter for work verb
	 * 
	 * @return a verb which is used to explain each works
	 */
	public String getWorkVerb();
}
