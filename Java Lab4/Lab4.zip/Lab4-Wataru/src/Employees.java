import java.util.ArrayList;

public class Employees {
	
	private ArrayList<Employee> aList = new ArrayList<Employee>();

	public Employees() {
		
		
	}
}
