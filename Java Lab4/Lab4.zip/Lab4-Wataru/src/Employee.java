
public abstract class Employee implements Employable{
	private String name;
	
	public Employee() {
		
	};
	
	abstract public double getOverTimePayRate();

	public final String getName() {
		return name;
	}

	public final void setName(String name) {
		this.name = name;
	}
}
