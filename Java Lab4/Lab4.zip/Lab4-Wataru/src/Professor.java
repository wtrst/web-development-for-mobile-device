
public class Professor extends Employee{

	private String teachingMajor;
	
	@Override
	public DressCode getDressCode() {
		// TODO Auto-generated method stub
		return DressCode.FANCY;
	}

	@Override
	public boolean isPaidSalary() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean postSecondaryEducationRequired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public String getWorkVerb() {
		// TODO Auto-generated method stub
		return "teach";
	}

	@Override
	public double getOverTimePayRate() {
		// TODO Auto-generated method stub
		return 2.0;
	}

}
