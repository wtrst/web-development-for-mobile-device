
public class HockeyPlayer extends Employee {

	private int numberOfGoals;
	
	@Override
	public DressCode getDressCode() {
		// TODO Auto-generated method stub
		return DressCode.JERSEY;
	}

	@Override
	public boolean isPaidSalary() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean postSecondaryEducationRequired() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getWorkVerb() {
		// TODO Auto-generated method stub
		return "play";
	}
	
	@Override
	public double getOverTimePayRate() {
		return 0.0;
		
	}
}
