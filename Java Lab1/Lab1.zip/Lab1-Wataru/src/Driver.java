/**
 * 
 * @author Wataru Sato
 *
 */
public class Driver {
	public static void main(String[] args) {
		Model m1 = new Model("Susan", "Smith", 70, 120.0, false, true);
		Model m2 = new Model("Tiger", "Woods", 72, 190.0, true, false);
		Model m3 = new Model("Susan", "Smith", 70, 120.0, true, false);

		m1.printDetails();
		System.out.println("---------------------");
		m2.printDetails();
		System.out.println("=====================");
		m3.displayModelDetails();
		System.out.println("=====================");
		m3.displayModelDetails(true);

	}
}
