
public class Knight extends ChessPiece {

	public Knight() {
		importance = 2;
	}

	@Override
	public void move() {
		System.out.println("like an L");
		
	}

	@Override
	public String toString() {
		return "Knight [importance=" + importance + "]";
	}

}
