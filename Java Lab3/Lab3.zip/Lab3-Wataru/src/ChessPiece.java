/**
 * 
 * @author Wataru Sato
 *
 */
public abstract class ChessPiece {
	protected int importance;

	public final int getImportance() {
		return importance;
	}

	public final void setImportance(int importance) {
		this.importance = importance;
	}

	public abstract void move();

	@Override
	public String toString() {
		return "ChessPiece [importance=" + importance + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + importance;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof ChessPiece))
			return false;
		ChessPiece other = (ChessPiece) obj;
		if (importance != other.importance)
			return false;
		return true;
	};

}
