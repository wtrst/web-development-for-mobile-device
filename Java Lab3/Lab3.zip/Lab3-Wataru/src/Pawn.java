
public class Pawn extends ChessPiece {

	private boolean hasBeenPromoted = false;
	private ChessPiece newPiece;

	Knight knight = new Knight();
	Bishop bishop = new Bishop();
	Rock rock = new Rock();
	Queen queen = new Queen();
	King king = new King();

	public Pawn() {
		importance = 1;
	}

	@Override
	public void move() {
		System.out.println("forward 1");

	}

	@Override
	public String toString() {
		return "Pawn [importance=" + importance + "]";
	}

	public void promote(ChessPiece newPiece) {
		if ((newPiece != null) && (this.hasBeenPromoted == false) && (!(newPiece.equals(this))) && (!(newPiece.equals(king)))) {
			if (newPiece.equals(knight)) {
				setImportance(2);;
			} else if (newPiece.equals(bishop)) {
				setImportance(3);
			} else if (newPiece.equals(rock)) {
				setImportance(5);
			} else if (newPiece.equals(queen)) {
				setImportance(9);
			}
			setHasBeenPromoted(true);
		}
	}

	public final boolean isHasBeenPromoted() {
		return hasBeenPromoted;
	}

	public final void setHasBeenPromoted(boolean hasBeenPromoted) {
		this.hasBeenPromoted = hasBeenPromoted;
	}

	public final ChessPiece getNewPiece() {
		return newPiece;
	}

	public final void setNewPiece(ChessPiece newPiece) {
		this.newPiece = newPiece;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + (hasBeenPromoted ? 1231 : 1237);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (obj instanceof Pawn)
			return false;
		Pawn other = (Pawn) obj;
		if (hasBeenPromoted != other.hasBeenPromoted)
			return false;
		return true;
	}

}
