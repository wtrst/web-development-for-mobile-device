
public class Rock extends ChessPiece {

	public Rock() {
		importance = 5;
	}

	@Override
	public void move() {
		System.out.println("horizontally or vertically");

	}

	@Override
	public String toString() {
		return "Rock [importance=" + importance + "]";
	}

}
