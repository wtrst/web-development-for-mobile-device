
public class Bishop extends ChessPiece {

	public Bishop() {
		importance = 3;
	}

	@Override
	public void move() {
		System.out.println("diagonally");

	}

	@Override
	public String toString() {
		return "Bishop [importance=" + importance + "]";
	}

}
