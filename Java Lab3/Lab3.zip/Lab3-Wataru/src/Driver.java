
public class Driver {
	public static void main(String[] args) {
		Pawn pawn = new Pawn();
		Knight knight = new Knight();
		Bishop bishop = new Bishop();
		Rock rock = new Rock();
		Queen queen = new Queen();
		King king = new King();

//		pawn.move();
//		knight.move();
//		bishop.move();
//		rock.move();
//		queen.move();
//		king.move();
		
		pawn.promote(bishop);
		
		System.out.println(pawn.getImportance());
		System.out.println(bishop.getImportance());
	}
}
