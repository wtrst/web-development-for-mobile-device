package ca.ciccc.java.sato.model;
/**
 * 
 * @author Wataru Sato
 *
 */
public abstract class ChessPiece {
	protected int importance;
	
	/**
	 * Getter for importance
	 * 
	 * @return importance which indicate a value of each pieces
	 */
	public final int getImportance() {
		return importance;
	}
	
	/**
	 * Setter for importance
	 * 
	 * @param importance which indicate a value of each pieces
	 */
	public final void setImportance(int importance) {
		this.importance = importance;
	}

	/**
	 * To display how piece move (abstract)
	 */
	public abstract void move();
	
	/**
	 * To string (overridden)
	 * 
	 * return a value of importance 
	 */
	@Override
	public String toString() {
		return "ChessPiece [importance=" + importance + "]";
	}

	/**
	 * To get hash code (overridden)
	 * 
	 * return hash code
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + importance;
		return result;
	}

	/**
	 * To compare 2 objects (overridden)
	 * 
	 * return result (true or false)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (obj == null) {
			return false;
		}

		if (!(obj instanceof ChessPiece)) {
			return false;
		}

		ChessPiece other = (ChessPiece) obj;
		if (importance != other.importance) {
			return false;
		}
		return true;
	};

}
