package ca.ciccc.java.sato.driver;

import ca.ciccc.java.sato.model.*;

/**
 * 
 * @author Wataru Sato
 *
 */
public class Driver {
	public static void main(String[] args) {
		Pawn pawn1 = new Pawn();
		Pawn pawn2 = new Pawn();
		Pawn pawn3 = new Pawn();
		Knight knight = new Knight();
		Bishop bishop = new Bishop();
		Rock rock = new Rock();
		Queen queen = new Queen();
		King king = new King();

		System.out.println("---How to move---------");
		pawn1.move();
		knight.move();
		bishop.move();
		rock.move();
		queen.move();
		king.move();
		System.out.println("");
		
		System.out.println("---Promote Pawn1 to Pawn2---------");
		pawn1.promote(pawn2);
		System.out.println("has been promoted : " + pawn1.isHasBeenPromoted());
		System.out.println("new piece : " + pawn1.getNewPiece());
		System.out.println("");
		
		System.out.println("---Promote Pawn1 to King---------");
		pawn1.promote(king);
		System.out.println("has been promoted : " + pawn1.isHasBeenPromoted());
		System.out.println("new piece : " + pawn1.getNewPiece());
		System.out.println("");
		
		System.out.println("---Promote Pawn1 to Bishop---------");
		pawn1.promote(bishop);
		System.out.println("has been promoted : " + pawn1.isHasBeenPromoted());
		System.out.println("new piece : " + pawn1.getNewPiece());
		System.out.println("");

		System.out.println("---Promote Pawn2 to Bishop---------");
		pawn2.promote(bishop);
		System.out.println("has been promoted : " + pawn2.isHasBeenPromoted());
		System.out.println("new piece : " + pawn2.getNewPiece());
		System.out.println("");
		
		System.out.println("Pawn1.equals(Pawn2) = " + pawn1.equals(pawn2));
		System.out.println("");
		
		
		System.out.println("---Promote Pawn3 to Knight---------");
		pawn3.promote(knight);
		System.out.println("has been promoted : " + pawn3.isHasBeenPromoted());
		System.out.println("new piece : " + pawn3.getNewPiece());
		System.out.println("");
		
		System.out.println("Pawn1.equals(Pawn3) = " + pawn1.equals(pawn3));
		
	}
}
