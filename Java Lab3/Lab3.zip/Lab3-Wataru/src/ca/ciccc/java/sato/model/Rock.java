package ca.ciccc.java.sato.model;
/**
 * 
 * @author Wataru Sato
 *
 */
public class Rock extends ChessPiece {

	/**
	 * Constructor
	 */
	public Rock() {
		importance = 5;
	}

	/**
	 * To display how rock piece move (overridden)
	 */
	@Override
	public void move() {
		System.out.println("horizontally or vertically");

	}

	/**
	 * To string (overridden)
	 * 
	 * return a value of importance
	 */
	@Override
	public String toString() {
		return "Rock [importance=" + importance + "]";
	}

}
