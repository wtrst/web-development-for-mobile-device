package ca.ciccc.java.sato.model;
/**
 * 
 * @author Wataru Sato
 *
 */
public class Pawn extends ChessPiece {

	private boolean hasBeenPromoted = false;
	private ChessPiece newPiece;

	Knight knight = new Knight();
	Bishop bishop = new Bishop();
	Rock rock = new Rock();
	Queen queen = new Queen();
	King king = new King();

	/**
	 * Constructor
	 */
	public Pawn() {
		importance = 1;
	}

	/**
	 * To display how pawn piece move (overridden)
	 */
	@Override
	public void move() {
		System.out.println("forward 1");

	}

	/**
	 * To string (overridden)
	 * 
	 * return a value of importance
	 */
	@Override
	public String toString() {
		return "Pawn [importance=" + importance + "]";
	}

	/**
	 * To promote pawn piece
	 * 
	 * @param newPiece
	 *            which piece pawn would be promote to
	 */
	public void promote(ChessPiece newPiece) {
		if ((newPiece != null) && (this.hasBeenPromoted == false) && (!(this.equals(newPiece)))
				&& (!(king.equals(newPiece)))) {
			setNewPiece(newPiece);
			setHasBeenPromoted(true);
		}
	}

	/**
	 * Getter for hasBeenPromoted
	 * 
	 * @return a statement which indicate whether pawn has been promoted to any
	 *         piece or not
	 */
	public final boolean isHasBeenPromoted() {
		return hasBeenPromoted;
	}

	/**
	 * Setter for hasBeenPromoted
	 * 
	 * @param hasBeenPromoted which handle whether pawn has been promoted or not
	 */
	public final void setHasBeenPromoted(boolean hasBeenPromoted) {
		this.hasBeenPromoted = hasBeenPromoted;
	}

	/**
	 * Getter for newPiece
	 * 
	 * @return newPiece that pawn would be after promoting
	 */
	public final ChessPiece getNewPiece() {
		return newPiece;
	}

	/**
	 * Setter for newPiece
	 * 
	 * @param newPiece that pawn would be after promoting
	 */
	public final void setNewPiece(ChessPiece newPiece) {
		this.newPiece = newPiece;
	}

	/**
	 * To get hash code (overridden)
	 * 
	 * return hash code
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + (hasBeenPromoted ? 1231 : 1237);
		return result;
	}

	/**
	 * To compare 2 objects (overridden)
	 * 
	 * return result (true or false)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Pawn)) {
			return false;
		}
		Pawn other = (Pawn) obj;
		if (hasBeenPromoted != other.hasBeenPromoted) {
			return false;
		}

		if (newPiece == null) {
			if (other.newPiece != null) {
				return false;
			}
		} else if (newPiece != other.newPiece) {
			return false;
		}

		return true;
	}

}
