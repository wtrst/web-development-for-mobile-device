package ca.ciccc.java.sato.model;
/**
 * 
 * @author Wataru Sato
 *
 */
public class Knight extends ChessPiece {

	/**
	 * Constructor
	 */
	public Knight() {
		importance = 2;
	}

	/**
	 * To display how knight piece move (overridden)
	 */
	@Override
	public void move() {
		System.out.println("like an L");
		
	}

	/**
	 * To string (overridden)
	 * 
	 * return a value of importance
	 */
	@Override
	public String toString() {
		return "Knight [importance=" + importance + "]";
	}

}
