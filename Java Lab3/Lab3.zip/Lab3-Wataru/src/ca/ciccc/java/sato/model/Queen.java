package ca.ciccc.java.sato.model;
/**
 * 
 * @author Wataru Sato
 *
 */
public class Queen extends ChessPiece {

	/**
	 * Constructor
	 */
	public Queen() {
		importance = 9;
	}

	/**
	 * To display how queen piece move (overridden)
	 */
	@Override
	public void move() {
		System.out.println("like a bishop or a rook");

	}

	/**
	 * To string (overridden)
	 * 
	 * return a value of importance
	 */
	@Override
	public String toString() {
		return "Queen [importance=" + importance + "]";
	}

}
