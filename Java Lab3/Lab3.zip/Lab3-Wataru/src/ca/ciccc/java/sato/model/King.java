package ca.ciccc.java.sato.model;
/**
 * 
 * @author Wataru Sato
 *
 */
public class King extends ChessPiece {

	/**
	 * Constructor
	 */
	public King() {
		importance = 1000;
	}

	/**
	 * To display how king piece move (overridden)
	 */
	@Override
	public void move() {
		System.out.println("one square");

	}

	/**
	 * To string (overridden)
	 * 
	 * return a value of importance
	 */
	@Override
	public String toString() {
		return "King [importance=" + importance + "]";
	}

}
