package ca.ciccc.java.sato.model;
/**
 * 
 * @author Wataru Sato
 *
 */
public class Bishop extends ChessPiece {

	/**
	 * Constructor
	 */
	public Bishop() {
		importance = 3;
	}

	/**
	 * To display how Bishop piece move (overridden)
	 */
	@Override
	public void move() {
		System.out.println("diagonally");

	}

	/**
	 * To string (overridden)
	 * 
	 * return a value of importance
	 */
	@Override
	public String toString() {
		return "Bishop [importance=" + importance + "]";
	}

}
