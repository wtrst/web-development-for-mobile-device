/**
 * 
 * @author Wataru Sato
 *
 */
public class Driver {
	public static void main(String[] args) {
		Province p1 = new Province();
		Province p2 = new Province("Ontario", "Toronto", 13);
		System.out.println("--Lab1------------");
		System.out.println(p1.getDetails());
		System.out.println(p2.getDetails());
		
		System.out.println("");
		
		System.out.println("--Lab2------------");
		Country c1 = new Country("Canada");
		c1.displayAllProvinces();
		System.out.println(c1.howManyHaveThisPopulation(4, 6));

	}
}
