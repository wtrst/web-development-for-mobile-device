/**
 * 
 * @author Wataru Sato
 *
 */
public class Country {

	private String name;
	private Province[] pObj;

	/**
	 * Constructor
	 * 
	 * @param name
	 */
	public Country(String name) {

		this.name = name;

		pObj = new Province[10];

		pObj[0] = new Province("Ontario", "Toronto", 13);
		pObj[1] = new Province("Quebec", "Quebec City", 8);
		pObj[2] = new Province("British Columbia", "Victoria", 4);
		pObj[3] = new Province("Alberta", "Edmonton", 4);
		pObj[4] = new Province("Manitoba", "Winnipeg", 4);
		pObj[5] = new Province("Saskatchewan", "Regina", 4);
		pObj[6] = new Province("Nova Scotia", "Halifax", 5);
		pObj[7] = new Province("New Brunswick", "Fredericton", 4);
		pObj[8] = new Province("Newfoundland and Labrador", "St. John's", 5);
		pObj[9] = new Province("Prince Edward Island", "Charlottetown", 4);

	}

	/**
	 * To display results of each province
	 */
	public void displayAllProvinces() {
		for (Province pro1 : pObj) {
			System.out.println(pro1.getDetails());
		}
	}

	/**
	 * To count a number of provinces
	 * 
	 * @param min
	 * @param max
	 * @return a number of provinces which have population following condition
	 */
	public int howManyHaveThisPopulation(int min, int max) {
		int count = 0;

		for (Province pro2 : pObj) {
			if ((pro2.getPopulationInMillions() >= min) && (pro2.getPopulationInMillions() <= max)) {
				count++;
			}
		}

		return count;
	}
}
