
public class Country {

	private String name;

	public Country() {

		String[] provinces = { "Ontario", "Quebec", "British Columbia", "Alberta", "Manitoba", "Saskatchewan",
				"Nova Scotia", "New Brunswick", "Newfoundland and Labrador", "Prince Edward Island" };
	}

	public static void main(String[] args) {
		Province p1 = new Province();
		Province p2 = new Province("Ontario", "Toronto", 13);

		System.out.println(p1.getDetails());
		System.out.println(p2.getDetails());

	}

	public void displayAllProvinces() {
		
	}
}
