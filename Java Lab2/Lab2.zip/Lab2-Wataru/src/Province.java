
public class Province {

	private String name;
	private String capital;
	private int populationInMillions;

	public static final int DEFAULT_POPULATION_MILLIONS = 4;
	public static final String DEFAULT_PROVINCE = "British Columbia";
	public static final String DEFAULT_CAPITAL = "Victoria";

	public Province(String province, String capital, int populationInMillion) {
		if (isValidPopulation(populationInMillion) && isValidProvince(province) && isValidCapitalCity(capital)) {
			this.populationInMillions = populationInMillion;
			this.name = province;
			this.capital = capital;
		} else {
			this.populationInMillions = DEFAULT_POPULATION_MILLIONS;
			this.name = DEFAULT_PROVINCE;
			this.capital = DEFAULT_CAPITAL;
		}
	}

	public Province() {
		this.populationInMillions = DEFAULT_POPULATION_MILLIONS;
		this.name = DEFAULT_PROVINCE;
		this.capital = DEFAULT_CAPITAL;
	}

	private boolean isValidProvince(String province) {
		String[] aryOfPro = { "Ontario", "Quebec", "British Columbia", "Alberta", "Manitoba", "Saskatchewan",
				"Nova Scotia", "New Brunswick", "Newfoundland and Labrador", "Prince Edward Island" };

		int i = 0;
		while (i < 10) {
			if (aryOfPro[i] == province) {
				return true;
			}
		}

		return false;
	}

	private boolean isValidCapitalCity(String capital) {
		String[] aryOfCap = { "Toronto", "Quebec City", "Victoria", "Edmonton", "Winnipeg", "Regina", "Halifax",
				"Fredericton", "St. John's", "Charlottetown" };

		for (int j = 0; j < 10; j++) {
			if (aryOfCap[j] == capital) {
				return true;
			}
		}

		return false;
	}

	private boolean isValidPopulation(int population) {

		if ((population >= 4) && (population <= 38)) {
			return true;
		}

		return false;
	}

	public final String getName() {
		return name;
	}

	public final void setName(String name) {
		this.name = name;
	}

	public final String getCapital() {
		return capital;
	}

	public final void setCapital(String capital) {
		this.capital = capital;
	}

	public final int getPopulationInMillions() {
		return populationInMillions;
	}

	public final void setPopulationInMillions(int populationInMillions) {
		this.populationInMillions = populationInMillions;
	}

	@Override
	public String toString() {
		return "Province [name=" + name + ", capital=" + capital + ", populationInMillions=" + populationInMillions
				+ "]";
	}

	public String getDetails() {
		return "The capital of " + getName() + " (pop. " + getPopulationInMillions() + " million) is " + getCapital();
	}
}
