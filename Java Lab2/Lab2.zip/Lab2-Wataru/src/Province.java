/**
 * 
 * @author Wataru Sato
 *
 */
public class Province {

	private String name;
	private String capital;
	private int populationInMillions;

	public static final int DEFAULT_POPULATION_MILLIONS = 4;
	public static final String DEFAULT_PROVINCE = "British Columbia";
	public static final String DEFAULT_CAPITAL = "Victoria";
	public static final int MIN_POPULATION = 4;
	public static final int MAX_POPULATION = 38;

	/**
	 * Constructor1
	 * 
	 * @param province
	 * @param capital
	 * @param populationInMillion
	 */
	public Province(String province, String capital, int populationInMillion) {
		if (isValidPopulation(populationInMillion) && isValidProvince(province) && isValidCapitalCity(capital)) {
			this.populationInMillions = populationInMillion;
			this.name = province;
			this.capital = capital;
		} else {
			this.populationInMillions = DEFAULT_POPULATION_MILLIONS;
			this.name = DEFAULT_PROVINCE;
			this.capital = DEFAULT_CAPITAL;
		}
	}

	/**
	 * Constructor2
	 */
	public Province() {
		this.populationInMillions = DEFAULT_POPULATION_MILLIONS;
		this.name = DEFAULT_PROVINCE;
		this.capital = DEFAULT_CAPITAL;
	}

	/**
	 * To valid province
	 * 
	 * @param province
	 * @return result whether province is part of array or not
	 */
	private boolean isValidProvince(String province) {
		String[] aryOfPro = { "Ontario", "Quebec", "British Columbia", "Alberta", "Manitoba", "Saskatchewan",
				"Nova Scotia", "New Brunswick", "Newfoundland and Labrador", "Prince Edward Island" };

		int i = 0;
		while (i < 10) {
			if (aryOfPro[i].equals(province)) {
				return true;
			}
			i++;
		}

		return false;
	}

	/**
	 * To valid capital city
	 * 
	 * @param capital
	 * @return result whether capital is part of array or not
	 */
	private boolean isValidCapitalCity(String capital) {
		String[] aryOfCap = { "Toronto", "Quebec City", "Victoria", "Edmonton", "Winnipeg", "Regina", "Halifax",
				"Fredericton", "St. John's", "Charlottetown" };

		for (int j = 0; j < 10; j++) {
			if (aryOfCap[j].equals(capital)) {
				return true;
			}
		}

		return false;
	}

	/**
	 * To valid population
	 * 
	 * @param population
	 * @return result whether population is part of array or not
	 */
	private boolean isValidPopulation(int population) {

		if ((population >= MIN_POPULATION) && (population <= MAX_POPULATION)) {
			return true;
		}

		return false;
	}

	/**
	 * Getter for name
	 * 
	 * @return name
	 */
	public final String getName() {
		return name;
	}

	/**
	 * Setter for name
	 * 
	 * @param name
	 */
	public final void setName(String name) {
		this.name = name;
	}

	/**
	 * Getter for capital
	 * 
	 * @return capital
	 */
	public final String getCapital() {
		return capital;
	}

	/**
	 * Setter for capital
	 * 
	 * @param capital
	 */
	public final void setCapital(String capital) {
		this.capital = capital;
	}

	/**
	 * Getter for population
	 * 
	 * @return population
	 */
	public final int getPopulationInMillions() {
		return populationInMillions;
	}

	/**
	 * Setter for population
	 * 
	 * @param populationInMillions
	 */
	public final void setPopulationInMillions(int populationInMillions) {
		this.populationInMillions = populationInMillions;
	}

	/**
	 * To string (overridden)
	 * 
	 * @return
	 */
	@Override
	public String toString() {
		return "Province [name=" + name + ", capital=" + capital + ", populationInMillions=" + populationInMillions
				+ "]";
	}

	/**
	 * To display a result
	 * 
	 * @return result
	 */
	public String getDetails() {
		return "The capital of " + getName() + " (pop. " + getPopulationInMillions() + " million) is " + getCapital();
	}
}
