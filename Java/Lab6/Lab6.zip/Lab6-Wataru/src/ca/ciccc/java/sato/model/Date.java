package ca.ciccc.java.sato.model;

import javax.xml.bind.ValidationException;

/**
 * 
 * @author Wataru Sato
 *
 */
public class Date {

	private int day;
	private int month;
	private int year;

	public Date(int day, int month, int year) {
		this.day = day;
		this.month = month;
		this.year = year;
	}

	/**
	 * Getter for day
	 * 
	 * @return day that user typed
	 */
	public final int getDay() {
		return day;
	}

	/**
	 * Setter for day
	 * 
	 * @param day
	 *            that user typed
	 */
	public final void setDay(int day) {
		this.day = day;
	}

	/**
	 * Getter for month
	 * 
	 * @return month that user typed
	 */
	public final int getMonth() {
		return month;
	}

	/**
	 * Setter for month
	 * 
	 * @param month
	 *            that user typed
	 */
	public final void setMonth(int month) {
		this.month = month;
	}

	/**
	 * Getter for year
	 * 
	 * @return year that user typed
	 */
	public final int getYear() {
		return year;
	}

	/**
	 * Setter for year
	 * 
	 * @param year
	 *            that user typed
	 */
	public final void setYear(int year) {
		this.year = year;
	}

	/**
	 * To calculate day of the week
	 * 
	 * @return day of the week
	 */
	public String getDayOfTheWeek() {
		boolean leap = isLeapYear();
		int year = getYear();
		int month = getMonth();
		int day = getDay();

		if (!(leap) && month == 2 && day > 28) {
			return null;
		} else {

			int num1 = (year % 100) / 12;
			int num2 = (year % 100) % 12;
			int num3 = num2 / 4;
			int num4 = day;
			int num5 = 0;
			switch (month) {
			case 1:
				num5 = 1;
				if (leap) {
					num5 -= 1;
				}
				break;
			case 2:
				num5 = 4;
				if (leap) {
					num5 -= 1;
				}
				break;
			case 3:
				num5 = 4;
				break;
			case 4:
				num5 = 0;
				break;
			case 5:
				num5 = 2;
				break;
			case 6:
				num5 = 5;
				break;
			case 7:
				num5 = 0;
				break;
			case 8:
				num5 = 3;
				break;
			case 9:
				num5 = 6;
				break;
			case 10:
				num5 = 1;
				break;
			case 11:
				num5 = 4;
				break;
			case 12:
				num5 = 6;
				break;
			}

			if (year / 100 == 16) {
				num5 += 6;
			} else if (year / 100 == 17) {
				num5 += 4;
			} else if (year / 100 == 18) {
				num5 += 2;
			} else if (year / 100 == 20) {
				num5 += 6;
			} else if (year / 100 == 21) {
				num5 += 4;
			}

			int num6 = (num1 + num2 + num3 + num4 + num5) % 7;

			String result = "";
			switch (num6) {
			case 0:
				result = "Saturday";
				break;
			case 1:
				result = "Sunday";
				break;
			case 2:
				result = "Monday";
				break;
			case 3:
				result = "Tuesday";
				break;
			case 4:
				result = "Wednesday";
				break;
			case 5:
				result = "Thursday";
				break;
			case 6:
				result = "Friday";
				break;
			}
			return result;
		}
	}

	/**
	 * To judge whether it is leap year or not
	 * 
	 * @return true or false
	 */
	private boolean isLeapYear() {
		if (getYear() % 400 == 0) {
			return true;
		}
		if ((getYear() % 4 == 0) && (getYear() % 100 != 0)) {
			return true;
		}
		return false;
	}

	@Override
	public String toString() {
		return "Date [day=" + day + ", month=" + month + ", year=" + year + "]";
	}

}
