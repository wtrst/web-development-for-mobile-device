package ca.ciccc.java.sato.view;

/**
 * 
 * @author Wataru Sato
 *
 */
public class View {

	InputReader iReader = new InputReader();

	/**
	 * To get date that user typed 
	 * @return date that user typed
	 */
	public String getInput() {
		System.out.print("Type a date (yyyy-mm-dd) or \"quit\" to exit : ");
		return iReader.getStringInput();
	}

	/**
	 * To display date
	 * @param year that user typed
	 * @param month that user typed
	 * @param day that user typed
	 * @param dayOfTheWeek which is calculated
	 */
	public void dispDate(int year, String month, int day, String dayOfTheWeek) {
		System.out.println(month + " " + day + ", " + year + " was on " + dayOfTheWeek);
	}

}
