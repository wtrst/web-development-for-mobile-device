package ca.ciccc.java.sato.controller;

import ca.ciccc.java.sato.model.*;
import ca.ciccc.java.sato.view.*;

/**
 * 
 * @author Wataru Sato
 *
 */
public class Controller {

	public static void main(String[] args) {
		try {
			View view = new View();

			String dt = view.getInput();
			while (!(dt.equals("quit"))) {
				int y = Integer.parseInt(dt.split("-")[0]);
				int m = Integer.parseInt(dt.split("-")[1]);
				int d = Integer.parseInt(dt.split("-")[2]);

				Date date = new Date(d, m, y);
				String dayOfTheWeek = date.getDayOfTheWeek();
				
				if (m > 12 || d > 31) {
					System.out.println("It is NOT a valid date!");
				} else if ((m == 2 || m == 4 || m == 6 || m == 9 || m == 11) && d > 30) {
					System.out.println("It is NOT a valid date!");
				}else if (dayOfTheWeek == null) {
					System.out.println("It is NOT a valid date!");
				}else {
				String month = "";
				switch (m) {
				case 1:
					month = "January";
					break;
				case 2:
					month = "February";
					break;
				case 3:
					month = "March";
					break;
				case 4:
					month = "April";
					break;
				case 5:
					month = "May";
					break;
				case 6:
					month = "June";
					break;
				case 7:
					month = "July";
					break;
				case 8:
					month = "August";
					break;
				case 9:
					month = "September";
					break;
				case 10:
					month = "October";
					break;
				case 11:
					month = "November";
					break;
				case 12:
					month = "December";
					break;
					}
					view.dispDate(y, month, d, dayOfTheWeek);
				}
				dt = view.getInput();
			}

			System.out.println("You exited. Thank you.");

		} catch (Exception e) {
			System.out.println("What you typed is NOT allowed! Try again.");
			System.out.println(e);
		}

	}

}
