package ca.ciccc.java.sato.model;

/**
 * 
 * @author Wataru Sato
 *
 */
public class Name {
	private String name;
	
	/**
	 * Constructor
	 * 
	 * @param name which is author name
	 */
	public Name(String name) {
		this.name = name;
	}

	/**
	 * Getter for name
	 * 
	 * @return name which is author name
	 */
	public final String getName() {
		return name;
	}

	/**
	 * Setter for name
	 * 
	 * @param name which is author name
	 */
	public final void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		Name other = (Name) obj;
		if (this.name == null) {
			if (other.name != null) {
				return false;
			}
		} else if (!name.equals(other.name)) {
			return false;
		}
		return true;
	}

}
