package ca.ciccc.java.sato.driver;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

import ca.ciccc.java.sato.model.Book;
import ca.ciccc.java.sato.model.InvalidArgumentException;
import ca.ciccc.java.sato.model.InvalidBookDateException;
import ca.ciccc.java.sato.model.Name;

/**
 * 
 * @author Wataru Sato
 *
 */
public class Bookstore {
	private ArrayList<Book> books;

	/**
	 * Constructor
	 */
	public Bookstore() {
		books = new ArrayList<Book>();
	}

	/**
	 * To add Book object into array list
	 * 
	 * @param first name of author
	 * @param last name of author
	 * @param title of book
	 * @param year that book has been published
	 */
	public void addBook(Name first, Name last, String title, int year) {
		try {
			books.add(new Book(first, last, title, year));
		} catch (InvalidArgumentException e) {
			System.out.println("Invalid Argument Exception occured");
			e.printStackTrace();
		} catch (InvalidBookDateException e) {
			System.out.println("Invalid Book Date Exception occured");
			e.printStackTrace();
		}
	}

	/**
	 * To display array list
	 */
	public void displayBooks() {
		Iterator<Book> book = books.iterator();

		while (book.hasNext()) {
			Book it = book.next();
			System.out.println("Author : " + it.getFirst() + " " + it.getLast());
			System.out.println("Title : " + it.getTitle());
			System.out.println("Published year : " + it.getYear());
			System.out.println("-----------------------------");
		}

	}

	public static void main(String[] arg) {
		Bookstore bookstore = new Bookstore();
		bookstore.addBook(new Name("Suzanne"), new Name("Collins"), "The Hunger Games", 2008);
		bookstore.addBook(new Name("J.K."), new Name("Rowling"), "Harry Potter and the Order of the Phoenix", 2004);
		bookstore.addBook(new Name("Harper"), new Name("Lee"), "To Kill a Mockingbird", 2006);
		bookstore.addBook(new Name("Jane"), new Name("Austen"), "Pride and Prejudice", 2000);
		bookstore.addBook(new Name("Stephenie"), new Name("Meyer"), "Twilight", 2005);
		
		System.out.println("[ Before Sort ]");
		bookstore.displayBooks();
		Collections.sort(bookstore.books);
		System.out.println("");
		System.out.println("[ After Sort ]");
		bookstore.displayBooks();
		
	}
}
