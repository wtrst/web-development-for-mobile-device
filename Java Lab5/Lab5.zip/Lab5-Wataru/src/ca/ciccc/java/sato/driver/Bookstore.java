package ca.ciccc.java.sato.driver;
import java.util.ArrayList;

import ca.ciccc.java.sato.model.Book;
import ca.ciccc.java.sato.model.Name;

public class Bookstore {
	private ArrayList<Book> books;
	
	public Bookstore(Name first, Name last, String title, int year) {
		books = new ArrayList<Book>();
		addBook(first, last, title, year);
	}
	
	public void addBook(Name first, Name last, String title, int year) {
		books.add(new Book(first, last, title, year));
	}
	
	public void displayBooks() {
		
	}
}
