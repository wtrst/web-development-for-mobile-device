package ca.ciccc.java.sato.model;

/**
 * 
 * @author Wataru Sato
 *
 */
public class Book implements Comparable<Book> {
	private Name first;
	private Name last;
	private String title;
	private int year;

	/**
	 * Constructor
	 * 
	 * @param first
	 * @param last
	 * @param title
	 * @param year
	 * @throws InvalidArgumentException
	 * @throws InvalidBookDateException
	 */
	public Book(Name first, Name last, String title, int year) throws InvalidArgumentException, InvalidBookDateException {
		setFirst(first);
		setLast(last);
		setTitle(title);
		setYearPublished(year);
	}

	/**
	 * Setter for first name
	 * 
	 * @param first
	 * @throws InvalidArgumentException
	 */
	public final void setFirst(Name first) throws InvalidArgumentException {
		try {
			if (first == null) {
				throw new InvalidArgumentException("This parameter(first name) is null.");
			} else {
				this.first = first;
			}
		} catch (Exception e) {
			System.out.println("Exception Error");
			System.out.println(e);
		}
	}

	/**
	 * Setter for last name
	 * 
	 * @param last
	 * @throws InvalidArgumentException
	 */
	public final void setLast(Name last) throws InvalidArgumentException {
		try {
			if (last == null) {
				throw new InvalidArgumentException("This parameter(last name) is null.");
			} else {
				this.last = last;
			}
		} catch (Exception e) {
			System.out.println("Exception Error");
			System.out.println(e);
		}
	}

	/**
	 * Setter for title of book
	 * 
	 * @param title
	 * @throws InvalidArgumentException
	 */
	public final void setTitle(String title) throws InvalidArgumentException{
		try {
			if (title.isEmpty()) {
				throw new InvalidArgumentException("This parameter(title) is empty.");
			} else {
				this.title = title;
			}
		} catch (Exception e) {

		}
	}

	/**
	 * Setter for published year of book
	 * 
	 * @param year
	 * @throws InvalidBookDateException
	 */
	public final void setYearPublished(int year) throws InvalidBookDateException{
		try {
			if (year > 2017) {
				throw new InvalidBookDateException("This parameter(year) is greater than 2017.");
			} else {
				this.year = year;
			}
		} catch (Exception e) {
			System.out.println("Exception Error");
			System.out.println(e);
		}
	}

	/**
	 * Getter for first name
	 * 
	 * @return first
	 */
	public final Name getFirst() {
		return first;
	}

	/**
	 * Getter for last name
	 * 
	 * @return last
	 */
	public final Name getLast() {
		return last;
	}

	/**
	 * Getter for title of book
	 * 
	 * @return title
	 */
	public final String getTitle() {
		return title;
	}

	/**
	 * Getter for published year of book
	 * 
	 * @return year
	 */
	public final int getYear() {
		return year;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		result = prime * result + year;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Book other = (Book) obj;
		if (title == null) {
			if (other.title != null) {
				return false;
			}
		} else if (!title.equals(other.title)) {
			return false;
		}
		if (year != other.year) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "Book [first=" + first + ", last=" + last + ", title=" + title + ", year=" + year + "]";
	}

	@Override
	public int compareTo(Book obj) {
		if (this.year < obj.year) {
			return 1;
		} else if (this.year > obj.year) {
			return -1;
		}
		return 0;
	}

}
