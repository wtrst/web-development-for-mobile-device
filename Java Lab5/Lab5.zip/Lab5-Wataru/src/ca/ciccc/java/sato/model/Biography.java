package ca.ciccc.java.sato.model;

/**
 * 
 * @author Wataru Sato
 *
 */
public final class Biography extends Book {
	private Name subject;

	/**
	 * Constructor
	 * 
	 * @param first name of author
	 * @param last name of author
	 * @param title of book
	 * @param year that book has been published
	 * @param subject which is Name object
	 * @throws InvalidArgumentException which is class to handle exception
	 * @throws InvalidBookDateException which is class to handle exception
	 */
	public Biography(Name first, Name last, String title, int year, Name subject)
			throws InvalidArgumentException, InvalidBookDateException {
		super(first, last, title, year);
		this.subject = subject;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((subject == null) ? 0 : subject.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Biography other = (Biography) obj;
		if (subject == null) {
			if (other.subject != null) {
				return false;
			}
		} else if (!subject.equals(other.subject)) {
			return false;
		}
		return true;
	}

}
